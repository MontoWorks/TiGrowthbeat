//
//  GPPlainMessageHandler.h
//  GrowthbeatSample
//
//  Created by TABATAKATSUTOSHI on 2016/06/15.
//  Copyright © 2016年 SIROK, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GPMessageHandler.h"

@interface GPPlainMessageHandler : NSObject <GPMessageHandler, UIAlertViewDelegate>

@end
