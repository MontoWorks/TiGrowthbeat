//
//  GPNoContentMessage.h
//  Growthbeat
//
//  Created by Shigeru Ogawa on 2016/06/26.
//  Copyright © 2016年 SIROK, Inc. All rights reserved.
//

#import "GPMessage.h"

@interface GPNoContentMessage : GPMessage

@end
