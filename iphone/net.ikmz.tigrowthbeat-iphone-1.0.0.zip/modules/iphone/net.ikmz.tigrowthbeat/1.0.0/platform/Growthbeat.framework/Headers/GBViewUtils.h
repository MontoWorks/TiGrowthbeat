//
//  GBViewUtils.h
//  Growthbeat
//
//  Created by Naoyuki Kataoka on 2015/09/10.
//  Copyright (c) 2015年 SIROK, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GBViewUtils : NSObject

+ (UIWindow *)getWindow;
+ (UIColor*) hexToUIColor:(NSString *)hex alpha:(CGFloat)a;
+ (NSString *)addDensityByPictureUrl:(NSString *)originalUrl;

@end
