//
//  GBUrlIntentHandler.h
//  GrowthbeatCore
//
//  Created by 堀内 暢之 on 2015/03/08.
//  Copyright (c) 2015年 SIROK, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GBIntentHandler.h"

@interface GBUrlIntentHandler : NSObject <GBIntentHandler>

@end
